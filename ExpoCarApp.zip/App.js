
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function App() {
  const [role, setRole] = useState(null);

  return (
    <View style={styles.container}>
      {!role && (
        <View style={styles.card}>
          <Text style={styles.title}>به نمایشگاه خودرو خوش آمدید</Text>
          <TouchableOpacity style={styles.buyerButton} onPress={() => setRole('buyer')}>
            <Text style={styles.buyerButtonText}>ورود خریدار خودرو</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.dealerButton} onPress={() => setRole('dealer')}>
            <Text style={styles.dealerButtonText}>ورود نمایشگاه دار</Text>
          </TouchableOpacity>
        </View>
      )}

      {role === 'buyer' && (
        <View style={styles.cardWhite}>
          <Text style={styles.sectionTitle}>بخش خریداران خودرو</Text>
          <Text>🔍 مشاهده خودروها، فیلتر و جستجو</Text>
          <Text>📩 ارسال پیام به نمایشگاه‌داران</Text>
          <TouchableOpacity style={styles.backButton} onPress={() => setRole(null)}>
            <Text style={styles.backButtonText}>بازگشت</Text>
          </TouchableOpacity>
        </View>
      )}

      {role === 'dealer' && (
        <View style={styles.cardWhite}>
          <Text style={styles.sectionTitle}>پنل نمایشگاه‌داران</Text>
          <Text>🚗 افزودن خودرو برای فروش</Text>
          <Text>📨 مدیریت پیام‌های مشتریان</Text>
          <TouchableOpacity style={styles.backButton} onPress={() => setRole(null)}>
            <Text style={styles.backButtonText}>بازگشت</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#2f855a',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  card: {
    width: '90%',
    backgroundColor: '#276749',
    padding: 20,
    borderRadius: 20,
    alignItems: 'center',
  },
  cardWhite: {
    width: '90%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 22,
    color: 'white',
    marginBottom: 20,
    fontWeight: 'bold',
  },
  buyerButton: {
    backgroundColor: '#9ae6b4',
    padding: 15,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
    marginBottom: 10,
  },
  buyerButtonText: {
    color: '#22543d',
    fontSize: 18,
    fontWeight: 'bold',
  },
  dealerButton: {
    backgroundColor: '#38a169',
    padding: 15,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
  },
  dealerButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#22543d',
  },
  backButton: {
    backgroundColor: '#38a169',
    marginTop: 20,
    padding: 10,
    borderRadius: 10,
    width: '100%',
    alignItems: 'center',
  },
  backButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
